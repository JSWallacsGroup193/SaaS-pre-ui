# Replit Fix Pack v3 — Monolith deploy

Drop into repo root. Publish.

Improvements:
- Copies `frontend/dist` into `backend/dist/public` for stable static path.
- Patches CORS from `CORS_ORIGIN` list.
- Swaps `bcrypt` imports to `bcryptjs` in source and deps.
- Ensures `/api` prefix and SPA fallback that excludes `/api`.
- Hydrates `.env` and starts with `dotenv-cli`.

Files:
- `.replit`, `replit.nix`
- `tools/*` patch and helper scripts
- `.env.example`, `README-REPLIT-FIX.md`

After publish, visit `/` for SPA and `/api/*` for API.
