/**
 * Serve static SPA from backend/dist/public with fallback excluding /api.
 */
const fs = require('fs');
const path = require('path');
const file = 'backend/src/main.ts';
if (!fs.existsSync(file)) process.exit(0);
let src = fs.readFileSync(file, 'utf8');
if (/express\.static\(.*public/.test(src)) process.exit(0);

if (!/from 'path'/.test(src)) {
  src = "import * as path from 'path';\n" + src;
}
if (!/from 'express'/.test(src) && !/\bas express\b/.test(src)) {
  src = "import * as express from 'express';\n" + src;
}

const listenIdx = src.indexOf('await app.listen');
if (listenIdx === -1) process.exit(0);

const staticBlock = `
// static serve for SPA from compiled assets
const server = app.getHttpAdapter().getInstance();
const clientDir = path.join(__dirname, 'public'); // points to backend/dist/public
server.use(express.static(clientDir));
server.get(/^\/(?!api($|\\/)).*/, (_req: any, res: any) => res.sendFile(path.join(clientDir, 'index.html')));
`;

src = src.slice(0, listenIdx) + staticBlock + src.slice(listenIdx);
fs.writeFileSync(file, src);
