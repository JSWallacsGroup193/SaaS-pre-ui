/**
 * Replace backend/src imports of 'bcrypt' with 'bcryptjs' and commonjs requires.
 */
const fs = require('fs');
const path = require('path');
const base = 'backend/src';
if (!fs.existsSync(base)) process.exit(0);

function walk(dir) {
  for (const e of fs.readdirSync(dir)) {
    const p = path.join(dir, e);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p);
    else if (p.endsWith('.ts') || p.endsWith('.js')) {
      let s = fs.readFileSync(p, 'utf8');
      const orig = s;
      s = s.replace(/from\s+['"]bcrypt['"]/g, "from 'bcryptjs'");
      s = s.replace(/require\((['"])bcrypt\1\)/g, "require('$1bcryptjs$1')");
      if (s !== orig) fs.writeFileSync(p, s);
    }
  }
}
walk(base);
