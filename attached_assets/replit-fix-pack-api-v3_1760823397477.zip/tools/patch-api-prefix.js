/**
 * Adds app.setGlobalPrefix('api') before listen if missing.
 */
const fs = require('fs');
const file = 'backend/src/main.ts';
if (!fs.existsSync(file)) process.exit(0);
let src = fs.readFileSync(file, 'utf8');
if (/setGlobalPrefix\(['"]api['"]\)/.test(src)) process.exit(0);

const idx = src.indexOf('await app.listen');
if (idx === -1) process.exit(0);
src = src.slice(0, idx) + "app.setGlobalPrefix('api');\n" + src.slice(idx);
fs.writeFileSync(file, src);
