/**
 * Creates .env from example if missing and fills defaults.
 */
const fs = require('fs');
const crypto = require('crypto');
const dst = '.env';
if (fs.existsSync(dst)) process.exit(0);
let example = fs.existsSync('.env.example') ? fs.readFileSync('.env.example','utf8') : '';
const kv = {};
for (const line of example.split(/\r?\n/)) {
  if (!line || line.trim().startsWith('#') || !line.includes('=')) continue;
  const [k, ...rest] = line.split('=');
  kv[k] = rest.join('=');
}
if (!kv.JWT_SECRET) kv.JWT_SECRET = crypto.randomBytes(32).toString('hex');
if (!kv.VITE_API_URL) kv.VITE_API_URL = '/api';
const out = Object.entries(kv).map(([k,v]) => `${k}=${v}`).join('\n') + '\n';
fs.writeFileSync(dst, out);
console.log('Created .env with keys:', Object.keys(kv).join(', '));
