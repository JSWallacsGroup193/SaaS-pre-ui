/**
 * Enables CORS from CORS_ORIGIN env if not already set.
 */
const fs = require('fs');
const file = 'backend/src/main.ts';
if (!fs.existsSync(file)) process.exit(0);
let src = fs.readFileSync(file, 'utf8');
if (/enableCors\(/.test(src)) process.exit(0);

const idx = src.indexOf('await app.listen');
if (idx === -1) process.exit(0);

const block = `
const origins = (process.env.CORS_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
app.enableCors({
  origin: origins.length ? origins : true,
  credentials: true
});
`;
src = src.slice(0, idx) + block + src.slice(idx);
fs.writeFileSync(file, src);
