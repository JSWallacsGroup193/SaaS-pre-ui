/**
 * Ensure vite/client types are included if frontend tsconfig exists.
 */
const fs = require('fs');
const p = 'frontend/tsconfig.json';
if (!fs.existsSync(p)) process.exit(0);
const j = JSON.parse(fs.readFileSync(p, 'utf8'));
j.compilerOptions = j.compilerOptions || {};
const types = new Set([...(j.compilerOptions.types || [])]);
types.add('vite/client');
j.compilerOptions.types = [...types];
fs.writeFileSync(p, JSON.stringify(j, null, 2));
