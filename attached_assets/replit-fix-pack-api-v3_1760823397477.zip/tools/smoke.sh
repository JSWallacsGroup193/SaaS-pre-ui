#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://localhost:3000}"
echo "GET $BASE/api/health or $BASE/api"
curl -sS "$BASE/api" || true
echo
echo "GET $BASE"
curl -sS "$BASE" | head -n 5 || true
echo
