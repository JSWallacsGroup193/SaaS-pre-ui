/**
 * Listen on process.env.PORT and 0.0.0.0.
 */
const fs = require('fs');
const file = 'backend/src/main.ts';
if (!fs.existsSync(file)) process.exit(0);
let src = fs.readFileSync(file, 'utf8');
if (/process\.env\.PORT/.test(src) && /0\.0\.0\.0/.test(src)) process.exit(0);
src = src.replace(/await\s+app\.listen\([^;]*\);?/, [
  'const port = process.env.PORT ? Number(process.env.PORT) : 3000;',
  "await app.listen(port, '0.0.0.0');"
].join('\n'));
fs.writeFileSync(file, src);
