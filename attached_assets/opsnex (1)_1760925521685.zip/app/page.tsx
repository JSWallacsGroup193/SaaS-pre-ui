"use client"

import { useState } from "react"
import { TextInput } from "@/components/ui/text-input"
import { NumberInput } from "@/components/ui/number-input"
import { SelectInput } from "@/components/ui/select-input"
import { TextArea } from "@/components/ui/text-area"
import { DateInput } from "@/components/ui/date-input"
import { Button } from "@/components/ui/button"

export default function Home() {
  const [temperature, setTemperature] = useState("72")
  const [notes, setNotes] = useState("")

  return (
    <main className="min-h-screen bg-slate-950 p-4 md:p-8">
      <div className="mx-auto max-w-4xl space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-100 mb-2">OpsNex Input Components</h1>
          <p className="text-slate-400">HVAC app dark theme with teal accents</p>
        </div>

        <section className="space-y-6 bg-slate-900 p-6 rounded-xl border border-slate-800">
          <h2 className="text-xl font-semibold text-slate-100">Service Request Form</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TextInput
              label="Customer Name"
              placeholder="Enter customer name"
              required
              helperText="Full name as it appears on the account"
            />

            <TextInput label="Email Address" type="email" placeholder="customer@example.com" required />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <NumberInput
              label="Temperature Setting"
              placeholder="72"
              value={temperature}
              onChange={(e) => setTemperature(e.target.value)}
              min={60}
              max={85}
              step={1}
              helperText="Desired temperature in Fahrenheit"
            />

            <SelectInput
              label="Service Type"
              required
              options={[
                { value: "", label: "Select a service" },
                { value: "maintenance", label: "Routine Maintenance" },
                { value: "repair", label: "Repair Service" },
                { value: "installation", label: "New Installation" },
                { value: "emergency", label: "Emergency Service" },
              ]}
            />
          </div>

          <DateInput label="Preferred Service Date" required helperText="Select your preferred date for service" />

          <TextArea
            label="Service Notes"
            placeholder="Describe the issue or service needed..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            showCharCount
            maxLength={500}
            autoResize
            helperText="Provide any additional details about your service request"
          />

          <div className="flex gap-4 pt-4">
            <Button variant="primary" size="lg">
              Submit Request
            </Button>
            <Button variant="ghost" size="lg">
              Cancel
            </Button>
          </div>
        </section>

        <section className="space-y-6 bg-slate-900 p-6 rounded-xl border border-slate-800">
          <h2 className="text-xl font-semibold text-slate-100">Error States</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TextInput
              label="Invalid Email"
              type="email"
              defaultValue="invalid-email"
              error="Please enter a valid email address"
            />

            <NumberInput label="Out of Range" defaultValue="100" error="Temperature must be between 60-85°F" />
          </div>

          <SelectInput
            label="Required Field"
            required
            error="Please select a service type"
            options={[
              { value: "", label: "Select a service" },
              { value: "maintenance", label: "Routine Maintenance" },
            ]}
          />

          <TextArea
            label="Too Long"
            defaultValue="This text exceeds the maximum length..."
            error="Message exceeds maximum length of 500 characters"
            showCharCount
            maxLength={500}
          />
        </section>

        <section className="space-y-6 bg-slate-900 p-6 rounded-xl border border-slate-800">
          <h2 className="text-xl font-semibold text-slate-100">Disabled States</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TextInput label="Disabled Text Input" placeholder="Cannot edit this field" disabled />

            <NumberInput label="Disabled Number Input" defaultValue="72" disabled />
          </div>

          <SelectInput
            label="Disabled Select"
            disabled
            options={[{ value: "maintenance", label: "Routine Maintenance" }]}
          />

          <DateInput label="Disabled Date" disabled />
        </section>
      </div>
    </main>
  )
}
