# Refrigeration Diagnostic Calculators

Includes:
- Superheat Calculator
- Subcooling Calculator
- Target Superheat Tool
- PT Chart Lookup

### Features
- Zustand offline store
- Mobile responsive
- Dashboard tab navigation
- NestJS-ready sync output format

To run in Replit:
```bash
npm install
npm run dev
```
