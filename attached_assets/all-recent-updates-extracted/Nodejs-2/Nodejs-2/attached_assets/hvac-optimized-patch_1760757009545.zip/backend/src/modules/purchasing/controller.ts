import { Controller, Get, Post, Put, Param, Body, Req, Query } from '@nestjs/common';
import { PurchasingService } from './service';

@Controller('purchasing')
export class PurchasingController {
  constructor(private readonly service: PurchasingService) {}

  @Get()
  getAll(@Req() req: any, @Query('page') page = '1', @Query('pageSize') pageSize = '50') {
    const tenantId = req.user?.tenantId || req.query?.tenantId;
    return this.service.getPOs(String(tenantId), Number(page), Number(pageSize));
  }

  @Post()
  create(@Body() body: { tenantId?: string; skuId: string; quantity: number }, @Req() req: any) {
    const tenantId = body.tenantId || req.user?.tenantId;
    return this.service.createPO({ ...body, tenantId });
  }

  @Put(':id/receive')
  receive(@Param('id') id: string) {
    return this.service.receivePO(id);
  }
}
