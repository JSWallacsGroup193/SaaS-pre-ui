import { Controller, Get, Post, Body, Req, Query } from '@nestjs/common';
import { InventoryService } from './service';

@Controller('inventory')
export class InventoryController {
  constructor(private readonly service: InventoryService) {}

  @Get('skus')
  getSKUs(@Req() req: any, @Query('q') q?: string, @Query('page') page = '1', @Query('pageSize') pageSize = '50') {
    const tenantId = req.user?.tenantId || req.query?.tenantId;
    return this.service.getSKUs(String(tenantId), q, Number(page), Number(pageSize));
  }

  @Post('skus')
  createSKU(@Body() body: { tenantId?: string; name: string; description?: string; barcode?: string }, @Req() req: any) {
    const tenantId = body.tenantId || req.user?.tenantId;
    return this.service.createSKU({ ...body, tenantId });
  }

  @Get('warehouses')
  getWarehouses(@Req() req: any) {
    const tenantId = req.user?.tenantId || req.query?.tenantId;
    return this.service.getWarehouses(String(tenantId));
  }

  @Post('warehouses')
  createWarehouse(@Body() body: { tenantId?: string; name: string }, @Req() req: any) {
    const tenantId = body.tenantId || req.user?.tenantId;
    return this.service.createWarehouse({ ...body, tenantId });
  }

  @Get('bins')
  getBins(@Req() req: any) {
    const tenantId = req.user?.tenantId || req.query?.tenantId;
    return this.service.getBins(String(tenantId));
  }

  @Post('bins')
  createBin(@Body() body: { warehouseId: string; name: string }) {
    return this.service.createBin(body);
  }
}
