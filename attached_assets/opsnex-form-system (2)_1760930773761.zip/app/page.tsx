"use client"

import { OpsNexSidebar } from "@/components/opsnex-sidebar"
import { OpsNexTopBar } from "@/components/opsnex-topbar"
import { Form } from "@/components/form/form"
import { FormSection } from "@/components/form/form-section"
import { FormField } from "@/components/form/form-field"
import { FormActions } from "@/components/form/form-actions"
import { MultiStepForm } from "@/components/form/multi-step-form"
import { Button } from "@/components/ui/button"
import { z } from "zod"
import { useState } from "react"

// Example schema for work order
const workOrderSchema = z.object({
  customerId: z.string().min(1, "Customer is required"),
  address: z.string().min(1, "Service address is required"),
  jobType: z.string().min(1, "Job type is required"),
  priority: z.string().optional(),
  notes: z.string().optional(),
  technicianId: z.string().min(1, "Technician is required"),
  scheduledDate: z.string().min(1, "Scheduled date is required"),
  estimatedHours: z.string().optional(),
})

type WorkOrderFormData = z.infer<typeof workOrderSchema>

export default function Page() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showMultiStep, setShowMultiStep] = useState(false)
  const [activeNav, setActiveNav] = useState("work-orders")

  const handleSubmit = async (data: WorkOrderFormData) => {
    setIsSubmitting(true)
    console.log("Form submitted:", data)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsSubmitting(false)
    alert("Work order created successfully!")
  }

  const handleAutoSave = async (data: WorkOrderFormData) => {
    console.log("Auto-saving:", data)
    // Simulate auto-save
    await new Promise((resolve) => setTimeout(resolve, 500))
  }

  const handleLogout = () => {
    console.log("Logging out...")
    alert("Logout clicked")
  }

  const handleSearch = (query: string) => {
    console.log("Searching for:", query)
  }

  const handleNotificationClick = () => {
    console.log("Notifications clicked")
    alert("You have 3 new notifications")
  }

  const userInfo = {
    name: "John Smith",
    role: "Field Manager",
    avatar: "/placeholder-user.jpg",
  }

  // Mock data
  const customers = [
    { value: "1", label: "John Smith" },
    { value: "2", label: "Jane Doe" },
    { value: "3", label: "Bob Johnson" },
  ]

  const jobTypes = [
    { value: "installation", label: "Installation" },
    { value: "repair", label: "Repair" },
    { value: "maintenance", label: "Maintenance" },
    { value: "inspection", label: "Inspection" },
  ]

  const priorities = [
    { value: "low", label: "Low" },
    { value: "medium", label: "Medium" },
    { value: "high", label: "High" },
    { value: "urgent", label: "Urgent" },
  ]

  const technicians = [
    { value: "1", label: "Mike Wilson" },
    { value: "2", label: "Sarah Davis" },
    { value: "3", label: "Tom Brown" },
  ]

  if (showMultiStep) {
    return (
      <>
        <OpsNexTopBar
          pageTitle="Multi-Step Work Order"
          subtitle="Create a new work order in multiple steps"
          userName={userInfo.name}
          userAvatar={userInfo.avatar}
          notifications={3}
          onSearch={handleSearch}
          onNotificationClick={handleNotificationClick}
          onLogout={handleLogout}
        />
        <OpsNexSidebar activeItem={activeNav} onNavigate={setActiveNav} userInfo={userInfo} onLogout={handleLogout}>
          <div className="min-h-screen bg-slate-900 p-8 pt-24">
            <div className="mx-auto max-w-3xl space-y-6">
              <div className="flex items-center justify-between">
                <h1 className="text-3xl font-bold text-slate-100">Multi-Step Work Order Form</h1>
                <Button variant="ghost" onClick={() => setShowMultiStep(false)} className="text-slate-300">
                  Switch to Single Form
                </Button>
              </div>

              <MultiStepForm
                steps={[
                  {
                    title: "Customer Information",
                    description: "Basic customer details",
                    fields: ["customerId", "address"],
                    content: (
                      <>
                        <FormField
                          name="customerId"
                          label="Customer"
                          component="select"
                          options={customers}
                          required
                          helperText="Select existing customer or create new"
                        />
                        <FormField
                          name="address"
                          label="Service Address"
                          component="input"
                          required
                          placeholder="123 Main St, City, State ZIP"
                        />
                      </>
                    ),
                  },
                  {
                    title: "Job Details",
                    description: "Specify the type and priority of work",
                    fields: ["jobType", "priority", "notes"],
                    content: (
                      <>
                        <FormField name="jobType" label="Job Type" component="select" options={jobTypes} required />
                        <FormField
                          name="priority"
                          label="Priority"
                          component="select"
                          options={priorities}
                          helperText="Set the urgency level"
                        />
                        <FormField
                          name="notes"
                          label="Notes"
                          component="textarea"
                          rows={4}
                          helperText="Any special instructions"
                          placeholder="Enter any additional details..."
                        />
                      </>
                    ),
                  },
                  {
                    title: "Scheduling",
                    description: "Assign technician and schedule",
                    fields: ["technicianId", "scheduledDate", "estimatedHours"],
                    content: (
                      <>
                        <FormField
                          name="technicianId"
                          label="Technician"
                          component="select"
                          options={technicians}
                          required
                          helperText="Assign a technician to this job"
                        />
                        <FormField name="scheduledDate" label="Scheduled Date" component="input" type="date" required />
                        <FormField
                          name="estimatedHours"
                          label="Estimated Hours"
                          component="input"
                          type="number"
                          placeholder="4"
                          helperText="Estimated time to complete"
                        />
                      </>
                    ),
                  },
                ]}
                onSubmit={handleSubmit}
                schema={workOrderSchema}
                loading={isSubmitting}
                showProgress
              />
            </div>
          </div>
        </OpsNexSidebar>
      </>
    )
  }

  return (
    <>
      <OpsNexTopBar
        pageTitle="Work Orders"
        subtitle="Create and manage HVAC work orders"
        userName={userInfo.name}
        userAvatar={userInfo.avatar}
        notifications={3}
        onSearch={handleSearch}
        onNotificationClick={handleNotificationClick}
        onLogout={handleLogout}
      />
      <OpsNexSidebar activeItem={activeNav} onNavigate={setActiveNav} userInfo={userInfo} onLogout={handleLogout}>
        <div className="min-h-screen bg-slate-900 p-8 pt-24">
          <div className="mx-auto max-w-3xl space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold text-slate-100">Create Work Order</h1>
              <Button variant="ghost" onClick={() => setShowMultiStep(true)} className="text-slate-300">
                Switch to Multi-Step
              </Button>
            </div>

            <Form
              onSubmit={handleSubmit}
              schema={workOrderSchema}
              loading={isSubmitting}
              autoSave
              onAutoSave={handleAutoSave}
            >
              <FormSection title="Customer Information" description="Basic customer details">
                <FormField
                  name="customerId"
                  label="Customer"
                  component="select"
                  options={customers}
                  required
                  helperText="Select existing customer or create new"
                />
                <FormField
                  name="address"
                  label="Service Address"
                  component="input"
                  required
                  placeholder="123 Main St, City, State ZIP"
                />
              </FormSection>

              <FormSection title="Job Details" description="Specify the type and priority of work" collapsible>
                <FormField name="jobType" label="Job Type" component="select" options={jobTypes} required />
                <FormField
                  name="priority"
                  label="Priority"
                  component="select"
                  options={priorities}
                  helperText="Set the urgency level"
                />
                <FormField
                  name="notes"
                  label="Notes"
                  component="textarea"
                  rows={4}
                  helperText="Any special instructions"
                  placeholder="Enter any additional details..."
                />
              </FormSection>

              <FormSection title="Scheduling" description="Assign technician and schedule" collapsible>
                <FormField
                  name="technicianId"
                  label="Technician"
                  component="select"
                  options={technicians}
                  required
                  helperText="Assign a technician to this job"
                />
                <FormField name="scheduledDate" label="Scheduled Date" component="input" type="date" required />
                <FormField
                  name="estimatedHours"
                  label="Estimated Hours"
                  component="input"
                  type="number"
                  placeholder="4"
                  helperText="Estimated time to complete"
                />
              </FormSection>

              <FormActions sticky>
                <Button type="button" variant="ghost" className="text-slate-300 hover:text-slate-100">
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting} className="bg-teal-500 text-white hover:bg-teal-600">
                  {isSubmitting ? "Creating..." : "Create Work Order"}
                </Button>
              </FormActions>
            </Form>
          </div>
        </div>
      </OpsNexSidebar>
    </>
  )
}
