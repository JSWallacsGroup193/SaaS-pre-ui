# HVAC Unified Tool Launcher

This dashboard links all HVAC tool suites:
- Electrical Tools
- Refrigeration Tools
- Airflow Tools

Each toolset must be mounted at:
- `/electrical`
- `/refrigeration`
- `/airflow`

Ideal for:
✅ Single-page embedded apps
✅ Mobile launcher / PWA entry point

To use:
1. Mount routes in React Router to each suite
2. Link this dashboard as root `/` or home view
