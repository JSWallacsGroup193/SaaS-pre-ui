import { useState } from 'react'
import GasPipeSizer from './GasPipeSizer'
import CombustionAirCalculator from './CombustionAirCalculator'
import CombustionReferenceTool from './CombustionReferenceTool'

const tabs = [
  { id: 'pipe', label: 'Gas Pipe Sizer', Component: GasPipeSizer },
  { id: 'air', label: 'Combustion Air', Component: CombustionAirCalculator },
  { id: 'ref', label: 'Reference Chart', Component: CombustionReferenceTool },
]

export default function CalculatorDashboard() {
  const [active, setActive] = useState('pipe')
  const Tab = tabs.find(t => t.id === active)?.Component
  return (
    <div>
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActive(t.id)}>{t.label}</button>
        ))}
      </div>
      {Tab && <Tab />}
    </div>
  )
}
