# HVAC Electrical Field Calculators

Includes:
- Ohm’s Law Calculator
- Capacitor Test Tool
- Motor Amps Checker
- Voltage Drop / Wire Size Tool

### Features
- Zustand-powered offline state
- Responsive UI for mobile/tablet
- Shared layout + tabbed dashboard
- Ready to run in Replit or Vite

### To Run:
```
npm install
npm run dev
```
