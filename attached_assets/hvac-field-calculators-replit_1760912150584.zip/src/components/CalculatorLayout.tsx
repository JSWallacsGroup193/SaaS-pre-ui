export default function CalculatorLayout({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div style={{ padding: '1rem', maxWidth: 600, margin: 'auto' }}>
      <h2>{title}</h2>
      {children}
    </div>
  )
}
