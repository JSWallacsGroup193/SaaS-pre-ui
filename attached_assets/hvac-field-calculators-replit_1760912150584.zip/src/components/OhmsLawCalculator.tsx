import { useState } from 'react'
import { v4 as uuidv4 } from 'uuid'
import { useCalculatorStore } from '../store/calculatorStore'

export default function OhmsLawCalculator() {
  const [V, setV] = useState<number | ''>('')
  const [I, setI] = useState<number | ''>('')
  const [R, setR] = useState<number | ''>('')
  const [result, setResult] = useState<any>(null)
  const addEntry = useCalculatorStore((s) => s.addEntry)

  const calculate = () => {
    if ([V, I, R].filter(val => val !== '').length !== 2) {
      alert('Please enter exactly two values')
      return
    }

    let v = V !== '' ? Number(V) : undefined
    let i = I !== '' ? Number(I) : undefined
    let r = R !== '' ? Number(R) : undefined

    if (v === undefined && i !== undefined && r !== undefined) v = i * r
    if (i === undefined && v !== undefined && r !== undefined) i = v / r
    if (r === undefined && v !== undefined && i !== undefined) r = v / i

    if (v !== undefined && i !== undefined && r !== undefined) {
      const P = v * i
      const entry = {
        id: uuidv4(),
        type: 'ohms-law' as const,
        inputs: { V, I, R },
        result: { V: v, I: i, R: r, P },
        synced: false,
        timestamp: new Date().toISOString(),
      }
      addEntry(entry)
      setResult(entry.result)
    }
  }

  return (
    <div>
      <h2>Ohm’s Law Calculator</h2>
      <input type="number" placeholder="Voltage (V)" value={V} onChange={(e) => setV(e.target.value === '' ? '' : +e.target.value)} />
      <input type="number" placeholder="Current (I)" value={I} onChange={(e) => setI(e.target.value === '' ? '' : +e.target.value)} />
      <input type="number" placeholder="Resistance (R)" value={R} onChange={(e) => setR(e.target.value === '' ? '' : +e.target.value)} />
      <button onClick={calculate}>Calculate</button>
      {result && (
        <div>
          <p>Voltage (V): {result.V} V</p>
          <p>Current (I): {result.I} A</p>
          <p>Resistance (R): {result.R} Ω</p>
          <p>Power (P): {result.P} W</p>
        </div>
      )}
    </div>
  )
}
