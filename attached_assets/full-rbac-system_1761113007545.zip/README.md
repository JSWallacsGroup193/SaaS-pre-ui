# HVAC RBAC System

Run:
- `npm run seed:rbac`
- `npm run seed:demo`
- Edit via React UI at `/admin/roles`