import { ErrorPage } from "@/components/error-page"

export default function NotFound() {
  return <ErrorPage errorCode={404} />
}
