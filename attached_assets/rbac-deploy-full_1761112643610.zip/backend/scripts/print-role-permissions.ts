// Real content for print-role-permissions.ts
