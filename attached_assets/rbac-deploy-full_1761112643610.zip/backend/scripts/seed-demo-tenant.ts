// Real content for seed-demo-tenant.ts
