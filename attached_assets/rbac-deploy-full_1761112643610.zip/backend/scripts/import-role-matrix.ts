// Real content for import-role-matrix.ts
