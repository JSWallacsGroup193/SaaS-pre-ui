// Real content for seed-rbac-complete.ts
