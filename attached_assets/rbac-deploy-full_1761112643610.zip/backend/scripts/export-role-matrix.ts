// Real content for export-role-matrix.ts
