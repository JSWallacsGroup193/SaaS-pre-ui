// Real content for permissions.decorator.ts
