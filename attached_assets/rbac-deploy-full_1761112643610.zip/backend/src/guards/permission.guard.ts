// Real content for permission.guard.ts
