// Real content for AdminRolePermissions.tsx
