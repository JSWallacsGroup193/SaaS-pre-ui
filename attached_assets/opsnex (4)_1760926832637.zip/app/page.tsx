"use client"

import { BaseCard } from "@/components/ui/base-card"
import { WorkOrderCard } from "@/components/ui/work-order-card"
import { KPICard } from "@/components/ui/kpi-card"
import { CalculatorCard } from "@/components/ui/calculator-card"
import { DollarSign, Users, Wrench, Clock } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-950 p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-12">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-slate-100 mb-2">OpsNex Card Components</h1>
          <p className="text-slate-400">HVAC app dark theme with teal accents</p>
        </div>

        {/* Base Card Section */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-100">Base Card</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <BaseCard>
              <h3 className="text-slate-100 font-semibold mb-2">Simple Card</h3>
              <p className="text-slate-400 text-sm">
                This is a basic card component with dark slate background and subtle border.
              </p>
            </BaseCard>

            <BaseCard onClick={() => alert("Card clicked!")}>
              <h3 className="text-slate-100 font-semibold mb-2">Clickable Card</h3>
              <p className="text-slate-400 text-sm">This card has hover effects and can be clicked. Try clicking it!</p>
            </BaseCard>
          </div>
        </section>

        {/* Work Order Cards Section */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-100">Work Order Cards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <WorkOrderCard
              status="scheduled"
              customer="John Smith"
              address="123 Main St, Springfield, IL 62701"
              timeSlot="Today, 2:00 PM - 4:00 PM"
              jobType="AC Maintenance"
              technicianName="Mike Johnson"
              onViewDetails={() => alert("View details clicked")}
            />

            <WorkOrderCard
              status="in-progress"
              customer="Sarah Williams"
              address="456 Oak Ave, Chicago, IL 60601"
              timeSlot="Today, 10:00 AM - 12:00 PM"
              jobType="Furnace Repair"
              technicianName="David Chen"
              onViewDetails={() => alert("View details clicked")}
            />

            <WorkOrderCard
              status="completed"
              customer="Robert Brown"
              address="789 Elm St, Naperville, IL 60540"
              timeSlot="Yesterday, 1:00 PM - 3:00 PM"
              jobType="HVAC Installation"
              technicianName="Lisa Martinez"
              onViewDetails={() => alert("View details clicked")}
            />

            <WorkOrderCard
              status="invoiced"
              customer="Emily Davis"
              address="321 Pine Rd, Aurora, IL 60505"
              timeSlot="Dec 15, 9:00 AM - 11:00 AM"
              jobType="Duct Cleaning"
              technicianName="Tom Anderson"
              onViewDetails={() => alert("View details clicked")}
            />
          </div>
        </section>

        {/* KPI Cards Section */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-100">KPI Cards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard title="Total Revenue" value="$48,392" trend={12.5} icon={<DollarSign className="w-10 h-10" />} />

            <KPICard title="Active Customers" value="1,284" trend={8.2} icon={<Users className="w-10 h-10" />} />

            <KPICard title="Jobs Completed" value="156" trend={-3.1} icon={<Wrench className="w-10 h-10" />} />

            <KPICard title="Avg Response Time" value="2.4 hrs" trend={-15.3} icon={<Clock className="w-10 h-10" />} />
          </div>
        </section>

        {/* Calculator Cards Section */}
        <section className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-100">Field Tools Calculators</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <CalculatorCard
              icon="❄️"
              name="BTU Calculator"
              description="Calculate cooling capacity"
              onClick={() => alert("BTU Calculator clicked")}
            />

            <CalculatorCard
              icon="📏"
              name="Duct Sizing"
              description="Size ductwork properly"
              onClick={() => alert("Duct Sizing clicked")}
            />

            <CalculatorCard
              icon="⚡"
              name="Load Calculator"
              description="Estimate heating/cooling load"
              onClick={() => alert("Load Calculator clicked")}
            />

            <CalculatorCard
              icon="💰"
              name="Cost Estimator"
              description="Quick job pricing"
              onClick={() => alert("Cost Estimator clicked")}
            />

            <CalculatorCard
              icon="🌡️"
              name="Temp Converter"
              description="Convert F to C and back"
              onClick={() => alert("Temp Converter clicked")}
            />

            <CalculatorCard
              icon="🔧"
              name="Refrigerant Charge"
              description="Calculate charge amount"
              onClick={() => alert("Refrigerant Charge clicked")}
            />

            <CalculatorCard
              icon="📊"
              name="Efficiency Rating"
              description="Calculate SEER/EER"
              onClick={() => alert("Efficiency Rating clicked")}
            />

            <CalculatorCard
              icon="🏠"
              name="Square Footage"
              description="Calculate room area"
              onClick={() => alert("Square Footage clicked")}
            />
          </div>
        </section>
      </div>
    </main>
  )
}
