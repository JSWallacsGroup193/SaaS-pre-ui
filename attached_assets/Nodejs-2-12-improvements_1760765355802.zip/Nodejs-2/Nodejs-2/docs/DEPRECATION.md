# API Versioning and Deprecation
- Stable: /api/v1
- Breaking changes land in /api/v2
- Add `Deprecated` notes in Swagger on endpoints to be removed
- Support windows: 90 days after announcing deprecation
