import { Module, Global } from '@nestjs/common';

@Global()
@Module({})
export class QueueModule {}
