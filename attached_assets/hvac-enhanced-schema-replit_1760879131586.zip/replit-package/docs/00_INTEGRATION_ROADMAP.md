# HVAC Dashboard - Complete Integration Roadmap
**Target Repository**: https://github.com/JSWallacsGroup193/SaaS-pre-ui

**Integration Goal**: Seamlessly add enterprise HVAC dashboard features to existing Next.js 15 + Drizzle ORM application

**Timeline**: 12-16 weeks (can be parallelized with team)

---

## 📊 Current Codebase Analysis

### ✅ What You Already Have
- **Framework**: Next.js 15 (App Router)
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Auth**: Basic authentication setup
- **UI Components**: Some existing components
- **Styling**: Tailwind CSS (assumed)
- **TypeScript**: Full TypeScript support

### 🎯 What We're Adding
- **Enterprise Dashboard**: 6+ dashboard views (Executive, Operations, Financial, etc.)
- **20+ HVAC Calculators**: Complete contractor tools module
- **15 User Roles**: Advanced permission system with granular access control
- **Security Features**: SSO, MFA, session management, encryption
- **Business Integrations**: QuickBooks, Twilio, SendGrid, AWS S3
- **Analytics & Reporting**: Real-time KPIs, charts, custom reports
- **Mobile Responsive**: WCAG 2.1 AA accessible design
- **85+ API Endpoints**: Complete REST API

---

## 🗂️ Integration Structure

Your repository will be enhanced with this structure:

```
SaaS-pre-ui/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── (auth)/                   # ✅ Existing - Enhanced
│   │   │   ├── login/
│   │   │   ├── register/
│   │   │   └── mfa/                  # 🆕 Add MFA flow
│   │   ├── (dashboard)/              # 🆕 New dashboard routes
│   │   │   ├── layout.tsx            # Dashboard layout with sidebar
│   │   │   ├── page.tsx              # Executive dashboard
│   │   │   ├── operations/           # Operations dashboard
│   │   │   ├── work-orders/          # Work order management
│   │   │   ├── inventory/            # Inventory management
│   │   │   ├── crm/                  # Customer management
│   │   │   ├── dispatch/             # Dispatch & scheduling
│   │   │   ├── financial/            # Financial dashboard
│   │   │   ├── contractor-tools/     # 20+ HVAC calculators
│   │   │   ├── users/                # User management
│   │   │   ├── roles/                # Role & permission management
│   │   │   └── settings/             # System settings
│   │   └── api/                      # ✅ Existing - Enhanced
│   │       ├── auth/                 # Enhanced auth endpoints
│   │       ├── dashboard/            # Dashboard data endpoints
│   │       ├── work-orders/          # Work order CRUD
│   │       ├── inventory/            # Inventory CRUD
│   │       ├── users/                # User management API
│   │       ├── roles/                # Role management API
│   │       ├── permissions/          # Permission API
│   │       ├── analytics/            # Analytics endpoints
│   │       ├── contractor-tools/     # Calculator APIs
│   │       └── integrations/         # Third-party integrations
│   ├── components/                   # ✅ Existing - Enhanced
│   │   ├── ui/                       # shadcn/ui components
│   │   ├── dashboard/                # 🆕 Dashboard-specific components
│   │   │   ├── KPICard.tsx
│   │   │   ├── DashboardGrid.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   └── Header.tsx
│   │   ├── charts/                   # 🆕 Chart components
│   │   │   ├── LineChart.tsx
│   │   │   ├── BarChart.tsx
│   │   │   ├── PieChart.tsx
│   │   │   └── AreaChart.tsx
│   │   ├── work-orders/              # 🆕 Work order components
│   │   ├── inventory/                # 🆕 Inventory components
│   │   ├── contractor-tools/         # 🆕 Calculator components
│   │   └── auth/                     # Enhanced auth components
│   ├── db/                           # ✅ Existing - Enhanced
│   │   ├── schema.ts                 # Enhanced with 38+ new tables
│   │   ├── migrations/               # New migration files
│   │   └── seed.ts                   # 🆕 Seed data for roles/permissions
│   ├── lib/                          # ✅ Existing - Enhanced
│   │   ├── auth/                     # Enhanced auth utilities
│   │   │   ├── jwt.ts
│   │   │   ├── mfa.ts                # 🆕 MFA utilities
│   │   │   ├── session.ts            # 🆕 Session management
│   │   │   └── permissions.ts        # 🆕 Permission checking
│   │   ├── integrations/             # 🆕 Third-party integrations
│   │   │   ├── quickbooks.ts
│   │   │   ├── twilio.ts
│   │   │   ├── sendgrid.ts
│   │   │   └── s3.ts
│   │   ├── calculations/             # 🆕 HVAC calculator logic
│   │   │   ├── btu-calculator.ts
│   │   │   ├── duct-sizing.ts
│   │   │   └── ... (20+ calculators)
│   │   └── utils/                    # Enhanced utilities
│   ├── hooks/                        # 🆕 Custom React hooks
│   │   ├── useAuth.ts
│   │   ├── usePermissions.ts
│   │   ├── useDashboard.ts
│   │   └── useWorkOrders.ts
│   ├── types/                        # 🆕 TypeScript types
│   │   ├── dashboard.ts
│   │   ├── work-order.ts
│   │   ├── user.ts
│   │   ├── role.ts
│   │   └── permission.ts
│   └── middleware.ts                 # Enhanced auth middleware
├── public/                           # ✅ Existing
│   └── images/                       # Dashboard icons and assets
├── .env.example                      # Enhanced with new vars
├── drizzle.config.ts                 # ✅ Existing - May need updates
├── tailwind.config.ts                # Enhanced with dashboard theme
├── package.json                      # New dependencies added
└── tsconfig.json                     # ✅ Existing
```

---

## 📋 Phase-by-Phase Implementation Plan

### **PHASE 1: Foundation & Database (Week 1-2)**

#### Week 1: Database Schema Enhancement

**Goal**: Add all new tables while preserving existing data

**Tasks**:
1. ✅ Backup existing database
2. Create migration for new tables:
   - Users enhancements (roles, teams, departments)
   - Roles & permissions (15 default roles)
   - Work orders
   - Inventory & SKUs
   - Customers & accounts
   - Audit logs
   - Sessions

**Deliverable**: Complete Drizzle schema with 38+ new tables

#### Week 2: Authentication Enhancement

**Goal**: Upgrade auth system with MFA and session management

**Tasks**:
1. Implement JWT refresh token rotation
2. Add MFA (TOTP, SMS, Email)
3. Session management with device tracking
4. Password policies
5. SSO preparation (SAML/OIDC infrastructure)

**Deliverable**: Enterprise-grade authentication system

---

### **PHASE 2: Core Dashboard UI (Week 3-4)**

#### Week 3: Dashboard Layout & Navigation

**Goal**: Build responsive dashboard shell

**Tasks**:
1. Create dashboard layout with sidebar
2. Build responsive header with user menu
3. Implement dark masculine theme
4. Add navigation routing
5. Create loading states and error boundaries

**Deliverable**: Working dashboard shell with navigation

#### Week 4: KPI Cards & Executive Dashboard

**Goal**: First functional dashboard view

**Tasks**:
1. Build reusable KPI card component
2. Implement Executive Dashboard with 8 KPIs:
   - Total Revenue
   - Active Work Orders
   - Open Opportunities
   - Customer Satisfaction
   - Technician Utilization
   - Inventory Value
   - Pending Invoices
   - Fleet Status
3. Add sparkline charts to KPI cards
4. Implement real-time data updates

**Deliverable**: Functional executive dashboard

---

### **PHASE 3: Work Orders Module (Week 5-6)**

#### Week 5: Work Order CRUD

**Goal**: Complete work order management

**Tasks**:
1. Database schema for work orders
2. API endpoints (CRUD operations)
3. Work order list view with filters
4. Work order detail view
5. Create/edit work order forms
6. Status workflow (Pending → In Progress → Completed)

**Deliverable**: Full work order management

#### Week 6: Work Order Analytics

**Goal**: Operations dashboard with work order insights

**Tasks**:
1. Work order status distribution chart
2. Completion rate trends
3. Technician performance table
4. Average completion time
5. Zero-dollar work order tracking
6. Callback rate analytics

**Deliverable**: Operations dashboard with analytics

---

### **PHASE 4: Inventory Module (Week 7-8)**

#### Week 7: Inventory Management

**Goal**: Stock tracking and warehouse management

**Tasks**:
1. Database schema for SKUs, warehouses, movements
2. API endpoints for inventory operations
3. Inventory list with search and filters
4. Stock adjustment interface
5. Transfer between warehouses
6. Reorder point alerts

**Deliverable**: Complete inventory system

#### Week 8: Purchasing & Analytics

**Goal**: Purchase order system and inventory analytics

**Tasks**:
1. Purchase order creation
2. Vendor management
3. Inventory valuation dashboard
4. Stock movement history
5. Low stock alerts
6. Inventory turnover metrics

**Deliverable**: Purchasing module with analytics

---

### **PHASE 5: Permission System (Week 9-10)**

#### Week 9: Role & Permission Infrastructure

**Goal**: Advanced RBAC system

**Tasks**:
1. 15 default roles with permissions
2. Permission checking middleware
3. Data-level scopes (own/team/department/all)
4. User management UI
5. Role assignment interface
6. Permission groups

**Deliverable**: Working permission system

#### Week 10: Advanced Permission Features

**Goal**: Enterprise permission capabilities

**Tasks**:
1. Team-scoped user management
2. Permission templates
3. Approval workflows
4. Permission delegation
5. Audit logs for permission changes
6. Self-service permission requests

**Deliverable**: Enterprise-grade access control

---

### **PHASE 6: Contractor Tools (Week 11-12)**

#### Week 11: Core Calculators (10 calculators)

**Goal**: First set of HVAC calculators

**Tasks**:
1. BTU Load Calculator
2. Duct Sizing Calculator
3. Airflow Calculator (CFM)
4. Refrigerant Charge Calculator
5. Static Pressure Calculator
6. Superheat/Subcooling Calculator
7. Tonnage Calculator
8. SEER Calculator
9. Psychrometric Calculator
10. Delta-T Calculator

**Deliverable**: 10 working calculators

#### Week 12: Advanced Calculators & Tools (10+ calculators)

**Goal**: Complete calculator suite

**Tasks**:
1. Pressure Drop Calculator
2. Heat Load Calculator
3. Blower Motor HP Calculator
4. Condensate Pump Sizing
5. Expansion Valve Sizing
6. Refrigerant Pipe Sizing
7. Evaporator Coil Sizing
8. Condenser Sizing
9. Filter Sizing Calculator
10. Thermostat Wire Guide
11. PT Chart Tool (Refrigerants)
12. Calculation history & saving

**Deliverable**: 20+ calculators with history

---

### **PHASE 7: Financial & CRM (Week 13-14)**

#### Week 13: Financial Dashboard

**Goal**: Financial analytics and reporting

**Tasks**:
1. Revenue metrics (daily, weekly, monthly, YTD)
2. Accounts receivable summary
3. Expense tracking
4. Profitability analysis
5. Invoice management
6. Payment tracking

**Deliverable**: Financial dashboard

#### Week 14: CRM Module

**Goal**: Customer relationship management

**Tasks**:
1. Customer list and profiles
2. Lead pipeline management
3. Opportunity tracking
4. Customer communication history
5. Service history per customer
6. Customer satisfaction tracking

**Deliverable**: CRM module

---

### **PHASE 8: Integrations (Week 15-16)**

#### Week 15: Business Integrations

**Goal**: External system connections

**Tasks**:
1. QuickBooks OAuth integration
2. Customer/invoice sync
3. Twilio SMS integration
4. SendGrid email integration
5. AWS S3 file storage
6. Integration status monitoring

**Deliverable**: Working integrations

#### Week 16: Communication System

**Goal**: Multi-channel notifications

**Tasks**:
1. In-app notification system
2. Email notification templates
3. SMS notification triggers
4. Push notifications (preparation)
5. Notification preferences
6. Communication logs

**Deliverable**: Complete notification system

---

### **PHASE 9: Security Hardening (Week 17-18)**

#### Week 17: SSO & Advanced Auth

**Goal**: Enterprise authentication

**Tasks**:
1. SAML 2.0 integration
2. OIDC integration
3. Azure AD connector
4. Okta connector
5. Google Workspace SSO
6. SSO configuration UI

**Deliverable**: SSO implementation

#### Week 18: Security Features

**Goal**: Production security hardening

**Tasks**:
1. Rate limiting
2. IP whitelisting
3. Encryption at rest (field-level)
4. Audit log integrity (hash chain)
5. CSRF protection
6. Security headers (Helmet)
7. Input validation/sanitization
8. Penetration testing

**Deliverable**: Production-ready security

---

### **PHASE 10: Polish & Launch (Week 19-20)**

#### Week 19: Performance & Testing

**Goal**: Optimize and test

**Tasks**:
1. Database query optimization
2. Frontend bundle optimization
3. Caching strategy (Redis)
4. Unit test coverage (80%+)
5. E2E test suite
6. Load testing
7. Accessibility audit (WCAG 2.1 AA)

**Deliverable**: Optimized, tested application

#### Week 20: Documentation & Deployment

**Goal**: Launch preparation

**Tasks**:
1. API documentation (Swagger)
2. User documentation
3. Admin guide
4. Deployment to production
5. Backup automation
6. Monitoring setup (Sentry)
7. Training materials
8. Go-live checklist

**Deliverable**: Production deployment

---

## 🎯 Priority Quick Wins (Weeks 1-4)

If you need to show progress quickly, focus on these in order:

### Week 1: Visual Impact
1. ✅ Dashboard layout with dark masculine theme
2. ✅ Executive dashboard with 8 KPI cards
3. ✅ Responsive sidebar navigation
**Result**: Impressive dashboard shell

### Week 2: Functionality
1. ✅ Work order list and creation
2. ✅ User management (list, create, assign roles)
3. ✅ Basic permission enforcement
**Result**: Working core features

### Week 3: Business Value
1. ✅ 5 essential calculators (BTU, Duct Sizing, Airflow, Refrigerant, Static Pressure)
2. ✅ Work order analytics dashboard
3. ✅ Real-time KPI updates
**Result**: Immediate business value

### Week 4: Integration
1. ✅ QuickBooks invoice sync
2. ✅ SMS notifications via Twilio
3. ✅ Email notifications
**Result**: Connected ecosystem

---

## 📦 New Dependencies to Add

Add these to your `package.json`:

```json
{
  "dependencies": {
    "@tanstack/react-query": "^5.0.0",
    "@tanstack/react-table": "^8.10.0",
    "recharts": "^2.10.0",
    "date-fns": "^3.0.0",
    "zod": "^3.22.4",
    "react-hook-form": "^7.49.0",
    "@hookform/resolvers": "^3.3.0",
    "otplib": "^12.0.1",
    "qrcode": "^1.5.3",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "@aws-sdk/client-s3": "^3.0.0",
    "@sendgrid/mail": "^8.0.0",
    "twilio": "^4.0.0",
    "intuit-oauth": "^4.0.0"
  },
  "devDependencies": {
    "@types/bcryptjs": "^2.4.6",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/qrcode": "^1.5.5"
  }
}
```

---

## 🔧 Configuration Updates Needed

### 1. Environment Variables (.env)

Add these to your `.env`:

```bash
# Existing vars (keep these)
DATABASE_URL="postgresql://..."
NEXTAUTH_SECRET="..."
NEXTAUTH_URL="..."

# New additions
# JWT
JWT_SECRET="generate-with-openssl-rand-base64-32"
JWT_REFRESH_SECRET="generate-with-openssl-rand-base64-32"
JWT_EXPIRES_IN="15m"
JWT_REFRESH_EXPIRES_IN="7d"

# MFA
TOTP_ISSUER="HVAC Management"
TOTP_WINDOW=1

# Email (SendGrid)
SENDGRID_API_KEY="SG.xxx"
SENDGRID_FROM_EMAIL="noreply@yourdomain.com"
SENDGRID_FROM_NAME="HVAC Management"

# SMS (Twilio)
TWILIO_ACCOUNT_SID="ACxxx"
TWILIO_AUTH_TOKEN="xxx"
TWILIO_PHONE_NUMBER="+1234567890"

# Storage (AWS S3)
AWS_ACCESS_KEY_ID="AKIAxxx"
AWS_SECRET_ACCESS_KEY="xxx"
AWS_REGION="us-east-1"
AWS_S3_BUCKET="hvac-uploads"

# QuickBooks
QUICKBOOKS_CLIENT_ID="xxx"
QUICKBOOKS_CLIENT_SECRET="xxx"
QUICKBOOKS_REDIRECT_URI="http://localhost:3000/api/integrations/quickbooks/callback"
QUICKBOOKS_ENVIRONMENT="sandbox"

# Redis (optional - for caching)
REDIS_URL="redis://localhost:6379"

# Monitoring
SENTRY_DSN="https://xxx@sentry.io/xxx"
```

### 2. Tailwind Config Enhancement

```typescript
// tailwind.config.ts
import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Dark masculine theme
        primary: {
          50: "#f0f7ff",
          100: "#e0efff",
          200: "#b9ddff",
          300: "#7cc2ff",
          400: "#38a3ff",
          500: "#0080ff",
          600: "#0066d9",
          700: "#0052b3",
          800: "#003d80",
          900: "#002952",
        },
        dark: {
          50: "#f8f9fa",
          100: "#e9ecef",
          200: "#dee2e6",
          300: "#ced4da",
          400: "#adb5bd",
          500: "#6c757d",
          600: "#495057",
          700: "#343a40",
          800: "#212529",
          900: "#121517",
        },
        success: "#10b981",
        warning: "#f59e0b",
        danger: "#ef4444",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
```

---

## 🚦 Migration Strategy

### Database Migration Approach

**CRITICAL**: We'll use a safe migration strategy:

1. **Create new tables** (non-breaking)
2. **Add new columns** to existing tables (non-breaking)
3. **Migrate data** if needed (scripted)
4. **Never drop or modify** existing critical columns

### Steps:

```bash
# 1. Backup database
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql

# 2. Generate migration
npm run db:generate

# 3. Review migration SQL
cat drizzle/migrations/0001_*.sql

# 4. Apply migration
npm run db:migrate

# 5. Seed default data (roles, permissions)
npm run db:seed
```

---

## 📈 Success Metrics

Track these KPIs during implementation:

**Week 4 (MVP)**:
- ✅ Dashboard loads in < 2 seconds
- ✅ 3 dashboards working (Executive, Operations, Work Orders)
- ✅ User can create work order
- ✅ 5 calculators functional

**Week 8 (Core Complete)**:
- ✅ All 6 dashboards working
- ✅ 10 calculators functional
- ✅ Permission system enforced
- ✅ Work orders + Inventory modules complete

**Week 12 (Feature Complete)**:
- ✅ All 20+ calculators working
- ✅ All integrations connected
- ✅ MFA enabled
- ✅ 80%+ test coverage

**Week 20 (Production)**:
- ✅ All 85+ API endpoints documented
- ✅ WCAG 2.1 AA compliant
- ✅ < 200ms API response time (P95)
- ✅ Zero critical security vulnerabilities
- ✅ Production deployment successful

---

## 🎯 Next Steps

1. **Review this roadmap** - Confirm priorities and timeline
2. **I'll generate**:
   - ✅ Complete Drizzle schema (38+ tables)
   - ✅ Database migration files
   - ✅ Dashboard components (React)
   - ✅ API route handlers
   - ✅ Authentication enhancement
   - ✅ First 5 calculators
   - ✅ Step-by-step implementation guide

3. **You decide**:
   - Which phase to start with
   - Any priority changes
   - Team assignments

**Ready to begin?** Let me know and I'll start generating the actual code files!

---

**Document Version**: 1.0  
**Created**: 2025-10-19  
**Status**: Ready for Implementation 🚀
