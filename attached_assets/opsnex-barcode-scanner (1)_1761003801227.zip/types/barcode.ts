export interface SKUData {
  barcode: string
  description: string
  category: string
  stock: number
  location: string
}
