#!/bin/bash

echo "=========================================="
echo "HVAC Management System - Complete Schema Upgrade"
echo "✅ All 69 Tables Included"
echo "=========================================="
echo ""

# Check if we're in the right directory
if [ ! -d "backend" ]; then
    echo "❌ Error: backend/ directory not found"
    echo "Please run this script from your Replit project root"
    exit 1
fi

echo "Step 1: Creating backup..."
cd backend
pg_dump $DATABASE_URL > ../database_backup_$(date +%Y%m%d_%H%M%S).sql
if [ $? -eq 0 ]; then
    echo "✅ Backup created successfully"
else
    echo "❌ Backup failed! Stopping."
    exit 1
fi

echo ""
echo "Step 2: Backing up current schema..."
cp prisma/schema.prisma prisma/schema.prisma.backup
echo "✅ Current schema backed up"

echo ""
echo "Step 3: Schema is already in place at backend/prisma/schema.prisma"
echo "✅ New schema ready (69 tables)"

echo ""
echo "Step 4: Generating migration..."
echo "⚠️  You'll need to answer 'yes' to apply the migration"
echo ""
npx prisma migrate dev --name complete_enhanced_schema_v2

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "✅ Installation Complete!"
    echo "=========================================="
    echo ""
    echo "Verifying table count..."
    TABLE_COUNT=$(psql $DATABASE_URL -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';")
    echo "Database tables: $TABLE_COUNT"
    echo ""
    echo "Next steps:"
    echo "1. Test your application: npm run start:dev"
    echo "2. Verify existing features work"
    echo "3. Read REPLIT_QUICK_START.md for examples"
    echo ""
    echo "You now have 69 tables with complete HVAC features!"
else
    echo ""
    echo "❌ Migration failed!"
    echo ""
    echo "To rollback:"
    echo "1. psql \$DATABASE_URL < ../database_backup_*.sql"
    echo "2. cp prisma/schema.prisma.backup prisma/schema.prisma"
    echo "3. npx prisma generate"
fi
